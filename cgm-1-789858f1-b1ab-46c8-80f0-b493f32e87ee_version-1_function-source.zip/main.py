#!/usr/bin/env python
import http.client
import json
import datetime
from datetime import datetime, time, timedelta
import pandas as pd

conn = http.client.HTTPSConnection("sandbox-api.dexcom.com")
CLIENT_ID = "zFY4arMzQn5rf0hRbNbfDKQZff9175aF"
CLIENT_SECRET = "gMKbRit4PrKoJaOj"
REDIRECT_URI = ""
ACCESS_TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI0ZjRhNzAwYS04ZDU0LTQ5ZGYtYTg4OS0zOWVhOGQ1MWZmYjIiLCJhdWQiOiJodHRwczovL3NhbmRib3gtYXBpLmRleGNvbS5jb20iLCJzY29wZSI6WyJlZ3YiLCJjYWxpYnJhdGlvbiIsImRldmljZSIsImV2ZW50Iiwic3RhdGlzdGljcyIsIm9mZmxpbmVfYWNjZXNzIl0sImlzcyI6Imh0dHBzOi8vc2FuZGJveC1hcGkuZGV4Y29tLmNvbSIsImV4cCI6MTYzMzY1NjMwMCwiaWF0IjoxNjMzNjQ5MTAwLCJjbGllbnRfaWQiOiJ6Rlk0YXJNelFuNXJmMGhSYk5iZkRLUVpmZjkxNzVhRiJ9.YzqotqLPkVx39XGE9DMNabALXDeMn1gKxZ4QvtzxPxOC8LeJcTXG2a-Zq0owv3HpAYm-VYuDgL_4nBAxCrYfgxFrLl5taFnbevRoTg0tGeaF6fbnzjnSHc7CXVA2d4UT0DAnWaAIdAI1KbQlk2GR4x2Ys1wA4AYgFc5kzve77uwX0rZgi8cNJboF7Z740xST-I_EEXxknA_wzz1bdAL9e52dACx3XTOodrXTjJ5kvIi2TxJvS8tvHtZJUIkFstc-E9LzbgNr4F19GowRHN0JyV7cDJleH_RA6inqWJwTey6B4v4iXH-vGEyRf3iXdiP-BNkQ5ZbkO4eQn-xAGashTQ"
REFRESH_TOKEN = "d43d263d403995be3af5227801833e40"

PROJECT_ID = "covid-19-271622"
TOPIC_ID = 'cgm-dexcom'

def cgm(request = None):

  start_date='2020-06-16'
  end_date='2020-06-18'

  if request:
    request_json = request.get_json()
    if request.args and 'start_date' in request.args:
      start_date = request.args.get('start_date')
    if request_json and 'end_date' in request_json:
      end_date = request_json['end_date']


  info = token_refresh()
  access_token = info['access_token']
  #REFRESH_TOKEN = info['refresh_token']
  df_all = get_data(access_token, start_date, end_date)
  return df_all.to_string()



def publish_messages(project_id: str, topic_id: str, data: bytes) -> None:
  """Publishes multiple messages to a Pub/Sub topic."""
  # [START pubsub_quickstart_publisher]
  # [START pubsub_publish]
  from google.cloud import pubsub_v1


  publisher = pubsub_v1.PublisherClient()
  # The `topic_path` method creates a fully qualified identifier
  # in the form `projects/{project_id}/topics/{topic_id}`
  topic_path = publisher.topic_path(project_id, topic_id)

  try:
    print(f"Publishing message {data}")
    future = publisher.publish(topic_path, data)
    print(f"Result:", future.result())
    print(f"Published messages to {topic_path}.")

  except Exception as er:
    print("Could not publish a message: ", er)

  # [END pubsub_quickstart_publisher]
  # [END pubsub_publish]


def get_data(access_token: str, start_date: str, end_date: str):
  headers = {
      'authorization': f"Bearer {access_token}"
  }

  df_all = pd.DataFrame()
  for day in get_dates_array(start_date, end_date):
    start_date_time = day.strftime('%Y-%m-%dT%H:%M:%S')
    end_date_time = datetime.combine(day, time.max).strftime('%Y-%m-%dT%H:%M:%S')
    try:
      conn.request("GET", f"/v2/users/self/egvs?startDate={start_date_time}&endDate={end_date_time}", headers=headers)
      res = conn.getresponse()
      if res.status == 401:
        print("Token needs refreshment")
      elif res.status == 200:
        data_object = json.loads(res.read())
        df = pd.json_normalize(data_object['egvs'])

        #TODO setting of index??
        #date = pd.Timestamp(day.strftime('%Y-%m-%d'))
        #df = df.set_index(df['systemTime'].astype(str))

        df_all = df_all.append(df, sort=True)
        break #TODO fix
        print(df.to_string)
        #df = pd.DataFrame(response['activities-heart-intraday']['dataset'])
        # print("--"* 40 + day. strftime("%Y-%m-%d") + "--"* 40)
        # print(json.dumps(data_object, indent=2))
        #data_list.append((day.strftime('%Y-%m-%d'), json.dumps(data_object, indent=2)))
      else:
        print("Error, returned status:", res.status)
    except http.client.HTTPException as err:
      print('Exception', err)  #Todo


    message = df_all.to_string().strip().replace("\n", " ").replace("    "," ").replace("       ","")
    #print("Message", message)
    message_json = json.dumps({'message': message},)
    message_bytes = message_json.encode('utf-8')

    publish_messages(PROJECT_ID, TOPIC_ID, message_bytes)

  return df_all


def get_dates_array(start_date: str, end_date: str):
  start = datetime.strptime(start_date, "%Y-%m-%d")
  end = datetime.strptime(end_date, "%Y-%m-%d")
  return (start + timedelta(days=x) for x in range(0, (end-start).days+1))



# def obtain_access_token():
#
#   payload = "client_secret={your_client_secret}&client_id={CLIENT_ID}&code={your_authorization_code}&grant_type=authorization_code&redirect_uri={REDIRECT_URI}"
#   headers = {
#       'content-type': "application/x-www-form-urlencoded",
#       'cache-control': "no-cache"
#   }
#   conn.request("POST", "/v2/oauth2/token", payload, headers)
#   res = conn.getresponse()
#   data = res.read()
#   print(data.decode("utf-8"))

def token_refresh():
  payload = f"client_secret={CLIENT_SECRET}&client_id={CLIENT_ID}&refresh_token={REFRESH_TOKEN}&grant_type=refresh_token&redirect_uri={REDIRECT_URI}"
  headers = {
      'content-type': "application/x-www-form-urlencoded",
      'cache-control': "no-cache"
  }
  conn.request("POST", "/v2/oauth2/token", payload, headers)
  res = conn.getresponse()
  data = res.read()
  data_dict = json.loads(data)
  print(data.decode("utf-8"))
  return data_dict
